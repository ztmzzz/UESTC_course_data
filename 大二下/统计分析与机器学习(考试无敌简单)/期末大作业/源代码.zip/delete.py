# -*- coding: utf-8 -*-

import cv2
import os

from PIL import Image

if __name__ == '__main__':
    root = 'F:/机器学习/人脸数据集/classify'
    dir = os.listdir(root)  # train[]
    for dir1 in dir:  # dir1=train
        dir2 = os.listdir(root + '/' + dir1)  # 0[]
        for dir3 in dir2:  # dir3=0
            dir4 = os.listdir(root + '/' + dir1+'/'+dir3)  # img[]
            size = len(dir4)
            for i in range(size):
                if i < size / 2:
                    os.remove(root + '/' + dir1 + '/' + dir3 + '/' + dir4[i])
