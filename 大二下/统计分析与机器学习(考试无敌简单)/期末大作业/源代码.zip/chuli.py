# -*- coding: utf-8 -*-

import cv2
import os

from PIL import Image

if __name__ == '__main__':
    root = 'F:/机器学习/人脸数据集/anime_face'
    files = os.listdir(root)
    for file in files:
        filedir=root+'/'+file
        img = Image.open(filedir)
        a = img.resize((256, 256))
        a.save('F:/机器学习/人脸数据集/anime/'+file)


