# coding=utf-8
# -*- coding: utf-8 -*-
# Thanks to dataset provider:Copyright(c) 2018, seeprettyface.com, BUPT_GWY contributes the dataset.
import os
import torch
import torch.nn as nn
import torchvision.transforms as transforms
from PIL import Image
from torchvision.datasets import ImageFolder


class Cnn(nn.Module):
    def __init__(self):
        super(Cnn, self).__init__()
        self.layer1 = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2))
        self.layer2 = nn.Sequential(
            nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2))
        self.fc = nn.Linear(64 * 64 * 32, 2)

    def forward(self, x):
        out = self.layer1(x)
        out = self.layer2(out)
        out = out.reshape(out.size(0), -1)
        out = self.fc(out)
        return out


def train():
    model.train()
    total_step = len(train_loader)
    for epoch in range(num_epochs):
        for i, (images, labels) in enumerate(train_loader):
            outputs = model(images)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            if (i + 1) % 100 == 0:
                print('轮数 [{}/{}], 进度 [{}/{}], Loss: {:.4f}'
                      .format(epoch + 1, num_epochs, i + 1, total_step, loss.item()))
            torch.save(model.state_dict(), 'gender_model')


def test():
    model.eval()
    with torch.no_grad():
        correct = 0
        total = 0
        for images, labels in test_loader:
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
        print('正确率: {} %'.format(100 * correct / total))


if __name__ == '__main__':
    num_epochs = 4
    num_classes = 2
    batch_size = 50
    learning_rate = 0.00001
    size = (256, 256)
    transform = transforms.Compose([
        transforms.Resize(size),
        transforms.ToTensor(),
        transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))
    ]
    )
    train_data = ImageFolder(root='./data/gender/train', transform=transform)
    test_data = ImageFolder(root='./data/gender/test', transform=transform)
    train_loader = torch.utils.data.DataLoader(dataset=train_data,
                                               batch_size=batch_size,
                                               shuffle=True)

    test_loader = torch.utils.data.DataLoader(dataset=test_data,
                                              batch_size=batch_size,
                                              shuffle=False)

    choice = input("请输入数字来操作，0=开始新训练，1=测试模型，2=读取模型并训练\n")
    if choice == "0":
        model = Cnn()
        model.eval()
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), learning_rate)
        train()
        os.system("pause")
    elif choice == "1":
        model = Cnn()
        model.load_state_dict(torch.load('gender_model', map_location=torch.device('cpu')))
        model.eval()
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), learning_rate)
        test()
        os.system("pause")
    elif choice == "2":
        model = Cnn()
        model.load_state_dict(torch.load('gender_model', map_location=torch.device('cpu')))
        model.eval()
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), learning_rate)
        train()
        os.system("pause")
