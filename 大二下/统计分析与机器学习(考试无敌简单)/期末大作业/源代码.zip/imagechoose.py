import os
from shutil import copyfile
import random
if __name__ == '__main__':

    root = 'F:/机器学习/人脸数据集/anime'
    files = os.listdir(root)
    L1 = random.sample(range(0, len(files)), int(len(files)*0.2))
    for i in range(len(files)):
        if i in L1:
            target = "F:/机器学习/人脸数据集/classify/test/0/" + files[i]
        else:
            target = "F:/机器学习/人脸数据集/classify/train/0/" + files[i]
        source = "F:/机器学习/人脸数据集/anime/" + files[i]
        copyfile(source, target)
