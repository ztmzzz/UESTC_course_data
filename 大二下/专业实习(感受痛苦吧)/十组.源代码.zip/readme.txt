crawler为爬虫项目，main.py，main2.py，get211.py分别为爬虫的0.1版，0.2版，0.3版。学校情况.py通过json获取学校的信息。
0.1版为基础的爬取功能，0.2版增加了并行运行的能力，0.3版增加了对学校类型的判断。
dataProcess为数据处理项目，包含了原始数据的清洗，机器学习数据的导入，导入机器学习的结果，以及数据库的总体结构。
flaskWeb为网页的项目， 在app.py中完成了后端提供数据以及用Spark进行数据获取的工作，templates包含了各个网页文件。
ml为机器学习的项目，getData.py将原始数据随机分割为测试集和训练集，然后使用classify.py进行机器学习。输出的结果在resultData.csv中，模型文件为model。