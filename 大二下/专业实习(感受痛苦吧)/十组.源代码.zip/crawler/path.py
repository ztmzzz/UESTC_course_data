# class=ant-select-selectionant-select-selection--single

provinceScoreXpath = [
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[1]/div[1]/div/div[1]/div/div',
    r'//*[@id="form3"]/div/div/div/span/div/div',
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[1]/div[1]/div/div[3]/div/div']
planeXpath = [
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[2]/div[1]/div/div[1]/div/div',
    r'//*[@id="select0"]/div',
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[2]/div[1]/div/div[3]/div/div',
    r'//*[@id="form2"]/div/div/div/span/div/div',
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[2]/div[1]/div/div[5]/div/div'
]

# nextButtonXpath = r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[2]/div[2]/div[3]/div/div/ul/li[4]/a'
nextButtonXpath = ['',
                   r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[2]/div[2]/div[3]/div/div/ul/li[4]',
                   r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[3]/div[2]/div[3]/div/div/ul/li[4]']
subjectScoreXpath = [
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[3]/div[1]/div/div[1]/div/div',
    r'//*[@id="form3"]/div/div/div/span/div/div',
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[3]/div[1]/div/div[3]/div/div',
    r'//*[@id="form4"]/div/div/div/span/div/div',
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[3]/div[1]/div/div[5]/div/div']

bodyXpath = [
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[1]/div[2]/div[1]/table/tbody',
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[2]/div[2]/div[1]/table/tbody',
    r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[3]/div[2]/div[1]/table/tbody']

schoolXpath = r'//*[@id="root"]/div/div[1]/div/div/div/div[1]/div[2]/div/div[3]/div[2]/div[1]/span'
