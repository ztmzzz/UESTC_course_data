import urllib.request
import json
import re


#正则表达式
findName = re.compile(r"'name': '(.*?)',")   #学校名字
findAddress = re.compile(r"'address': '(.*?)',")  #学校位置
findWebsite = re.compile(r"'school_site': '(.*?)',")  #学校官网
findPhone = re.compile(r"'phone': '(.*?)',")   #学校官方电话
findEmail = re.compile(r"'email': '(.*?)',")  #学校电子邮箱
findBuiltDate = re.compile(r"'create_date': '(.*?)',")  #学校创建时间
findArea = re.compile(r"'area': (.*?),")  #学校占地面积（亩）
findManRate = re.compile(r"'men_rate': '(.*?)',")   #学校男生百分比
findWorkRate = re.compile(r"{'jobrate': {'job': {'.*?': '(.*?)'},")  #学校就业率


#获取一个json代码
def getJson(url):
    head = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    request = urllib.request.Request(url, headers=head)
    response = urllib.request.urlopen(request)
    content = response.read().decode("utf-8")
    # 返回的是json，那么就直接解码转为字典。不需要解析器bs了
    js = json.loads(content)
    return js


#从一个json代码提取一个学校的  学校名  地址  网站  电话  邮箱  创建时间  占地面积（亩）
def getData(js):
    js = str(js)
    data = []
    if js == '':     #如果url没有对应一个学校，json为空，不做处理
        return data
    #正则表达式匹配数据
    #学校名  地址  网站  电话  邮箱  创建时间  占地面积（亩）
    result1 = re.findall(findName,js)
    if len(result1) != 0:
        name = re.findall(findName,js)[0]
        data.append(name)
    else:
        data.append(" ")     #如果没有对应数据，这一项置为空字符串，后续导入数据库对数据格式的要求

    result2 = re.findall(findAddress,js)
    if len(result2) != 0:
        address = re.findall(findAddress,js)[0]
        data.append(address)
    else:
        data.append(" ")

    result3 = re.findall(findWebsite,js)
    if len(result3) != 0:
        website = re.findall(findWebsite,js)[0]
        data.append(website)
    else:
        data.append(" ")

    result4 = re.findall(findPhone,js)
    if len(result4) != 0:
        phone = re.findall(findPhone,js)[0]
        data.append(phone)
    else:
        data.append(" ")

    result5 = re.findall(findEmail,js)
    if len(result5) != 0:
        email = re.findall(findEmail,js)[0]
        data.append(email)
    else:
        data.append(" ")

    result6 = re.findall(findBuiltDate,js)
    if len(result6) != 0:
        builtDate = re.findall(findBuiltDate,js)[0]
        data.append(builtDate)
    else:
        data.append(" ")

    result7 = re.findall(findArea,js)
    if len(result7) != 0:
        area = re.findall(findArea,js)[0]
        data.append(area)
    else:
        data.append(" ")

    return data


#从一个json代码提取一个学校的  男生百分比   就业率
def getData2(js):
    js = str(js)
    data = []
    if js == '':  # 如果url没有对应一个学校，json为空，不做处理
        return data
    result1 = re.findall(findManRate,js)
    if len(result1) != 0:
        manRate = re.findall(findManRate,js)[0]
        data.append(manRate)
    else:
        data.append(" ")   #如果没有对应数据，这一项置为空字符串，后续导入数据库对数据格式的要求

    result2 = re.findall(findWorkRate, js)
    if len(result2) != 0:
        workRate = re.findall(findWorkRate, js)[0]
        data.append(workRate)
    else:
        data.append(" ")

    return data


def main():
    #遍历学校id，从0到3500
    for i in range(0,3501):
        f = open('学校概况信息.txt', 'a')
        schoolId = str(i)
        #包含一个学校的学校名、地址、网站、电话、邮箱、创建时间、占地面积（亩）的json文件的url
        url = 'https://static-data.eol.cn/www/2.0/school/'+schoolId+'/info.json'
        data = getData(getJson(url))
        if len(data) == 0:  #如果这个id没有对应一个学校，数据为空，不做处理
            print("")
        else:
            for j in data:
                print(j+'\t')
                f.write(j+'\t')

        # 包含一个学校的男生百分比和就业率的json文件的url
        url2 = 'https://static-data.eol.cn/www/school/'+schoolId+'/pc_jobdetail.json'
        data2 = getData2(getJson(url2))
        if len(data2) == 0:    #如果这个id没有对应一个学校，数据为空，不做处理
            print("")
        else:
            for k in data2:
                print(k + '\t')
                f.write(k + '\t')
            #在一行记录的最后，加上这个学校的校徽图片的url
            f.write('https://static-data.eol.cn/upload/logo/' + schoolId + '.jpg')
            f.write('\n')  #一个学校的数据记录完毕，换行
        print(i)
        f.close()
        #每次for循环都进行文件的打开和关闭，确保爬取到的数据及时被写入磁盘，不会滞留在内存缓冲区中


if __name__=="__main__" :
    main()